## 自我介绍 - Hello Everyone~

:one:**基本信息**：Barry Yan:id:  |  99年男生:eyes: |  天蝎座:scorpius:  |  来自中国   :+1:

:two:**工作经历**：Gopher :moon:	

:three:**爱好**：听音乐、敲代码、羽毛球、跑步:star:	

:four:**擅长领域**：Go、Java :star2:

:five:**座右铭**：做兴趣使然的Hero:rocket:

:six:**个人说明**：请不要叫我程序员，叫我工程师或Programmer:muscle:

:seven:**简介**：目前是一名Gopher，后端开发领域狂热爱好者，写作爱好者，CSDN后端领域优质创作者，阿里云技术社区乘风者计划专家博主，喜欢学习和总结，热爱技术分享，擅长语言有Java、Go等:sunny:

:eight:**E-mail**：1712229564@qq.com:love_letter:

---
### 博客主站：

**:monkey_face:CSDN**：https://blog.csdn.net/Mr_YanMingXin

:monkey:**51CTO**：https://blog.51cto.com/u_15654567

**:cow:阿里云技术社区**：https://developer.aliyun.com/profile/expert/gk7gux2h2w67c

**:hatching_chick:掘金**：https://juejin.cn/user/990022531286247

**:koala:Gitee**：https://gitee.com/yan_mingxin

:camel:**InfoQ写作社区**：https://www.infoq.cn/u/barryyan/publish

**:cat:GitHub**：https://github.com/ibarryyan

:rabbit:**GitHub博客**：https://ibarryyan.github.io/

---
### 技术专栏：

《玩转gRPC框架》https://blog.csdn.net/mr_yanmingxin/category_12172887.html


《个人技术总结》：https://www.processon.com/view/link/624015bf7d9c0807245f5ff8

---
### 其他：

**:penguin:公众号**：扯编程的淡

<img src="https://ibarryyan.oss-cn-hangzhou.aliyuncs.com/1.jpg" alt="img.png" style="zoom:50%;" />

Thanks!
