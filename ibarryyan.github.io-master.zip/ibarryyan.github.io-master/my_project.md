## 个人项目

`温馨提示`：请使用PC端访问哈，页面并没有在手机端做适配

> **基于数据可视化的高校毕业生就业管理系统**

**项目地址（服务器带宽较低，首次访问较慢）**：http://59.110.25.8:8080/

**账号密码**：

- 学校招生就业办部门：admin/123
- 院/系毕业生办公室：jsjls123456/123456
- 应/往届毕业生：201601010101/010101

## 个人博客

CSDN：https://blog.csdn.net/Mr_YanMingXin

## Gitee&GitHub

Gitee：https://gitee.com/yan_mingxin

GitHub：https://github.com/y1712229564

## 技术学习图谱

JVM知识图谱：https://www.processon.com/view/link/60cfe44a5653bb5cb4460acd

开发领域技术图谱：https://www.processon.com/view/link/624015bf7d9c0807245f5ff8

